from setuptools import setup

setup(name='to_distributions',
      version='0.1',
      description ='Gaussian distribution',
      packages=['to_distributions'],
      author = 'Oluwatofunmi Caulcrick',
      author_email='johncaul@yahoo.com',
      zip_safe=False
)